<?php 
    include 'mainheader.php';
    include 'mainbody.php';
    include 'mainfooter.php';
?>